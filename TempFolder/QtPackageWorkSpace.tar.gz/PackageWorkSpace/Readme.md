This Folder is for package the Qt-Project's Application.
We need to follow those steps to finished the package!
Step1: Copy the Application's exe file located in the build-xxx-Realease Folder!
Step2: Run the Script 'pack.sh Appname'(eg: ./pack.sh MusicPlayer)
Step3: The tar file is what you want to get!Just Enjoy it!

When you are finished to create the target,please clear the WorkSpace with this command: ./pack-clear.sh
