shopt -s extglob
rm -rf !(pack.sh|pack-clear.sh|pack-tail.sh|Readme.md)
